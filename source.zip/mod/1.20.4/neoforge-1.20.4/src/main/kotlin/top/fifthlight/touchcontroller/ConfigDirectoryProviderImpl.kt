package top.fifthlight.touchcontroller

import net.neoforged.fml.loading.FMLPaths
import top.fifthlight.touchcontroller.buildinfo.BuildInfo
import top.fifthlight.touchcontroller.common.config.ConfigDirectoryProvider
import java.nio.file.Path

object ConfigDirectoryProviderImpl : ConfigDirectoryProvider {
    override fun getConfigDirectory(): Path {
        val fmlConfigPath = FMLPaths.CONFIGDIR.get()
        return fmlConfigPath.resolve(BuildInfo.MOD_ID)
    }
}