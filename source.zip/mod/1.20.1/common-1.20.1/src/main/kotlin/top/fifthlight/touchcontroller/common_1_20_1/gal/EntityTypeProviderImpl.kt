package top.fifthlight.touchcontroller.common_1_20_1.gal

import kotlinx.collections.immutable.toPersistentList
import net.minecraft.core.registries.BuiltInRegistries
import top.fifthlight.combine.data.Identifier
import top.fifthlight.touchcontroller.common.gal.EntityTypeEntry
import top.fifthlight.touchcontroller.common.gal.EntityTypeProvider

/**
 * 读取所有实体类型：注册名 + 游戏内显示名。
 *
 * 1.20.1 里实体类型都在 [BuiltInRegistries.ENTITY_TYPE] 这张表里，
 * 显示名用 {@code EntityType#getDescription()}（会走语言文件，模组实体也有自己的名字）。
 */
object EntityTypeProviderImpl : EntityTypeProvider {
    override fun all() = BuiltInRegistries.ENTITY_TYPE
        .map { type ->
            val rl = BuiltInRegistries.ENTITY_TYPE.getKey(type)
            EntityTypeEntry(
                id = Identifier("${rl.namespace}:${rl.path}"),
                name = type.description.string,
            )
        }
        .sortedBy { it.id.toString() }
        .toPersistentList()
}
