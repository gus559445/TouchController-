package top.fifthlight.touchcontroller.common_1_20_1.gal

import kotlinx.collections.immutable.persistentListOf
import kotlinx.collections.immutable.persistentSetOf
import net.minecraft.world.item.Items
import top.fifthlight.combine.platform_1_20_1.FoodComponentImpl
import top.fifthlight.combine.platform_1_20_1.ItemFactoryImpl
import top.fifthlight.combine.platform_1_20_1.ItemImpl
import top.fifthlight.touchcontroller.common.config.ItemList
import top.fifthlight.touchcontroller.common.gal.DefaultItemListProvider

object DefaultItemListProviderImpl : DefaultItemListProvider {
    override val usableItems = ItemList(
        whitelist = persistentListOf(
            ItemImpl(Items.FISHING_ROD),
            ItemImpl(Items.SPYGLASS),
            ItemImpl(Items.MAP),
            ItemImpl(Items.SHIELD),
            ItemImpl(Items.KNOWLEDGE_BOOK),
            ItemImpl(Items.WRITABLE_BOOK),
            ItemImpl(Items.WRITTEN_BOOK),
            ItemImpl(Items.ENDER_EYE),
            ItemImpl(Items.ENDER_PEARL),
            ItemImpl(Items.POTION),
            ItemImpl(Items.SNOWBALL),
            ItemImpl(Items.EGG),
            ItemImpl(Items.SPLASH_POTION),
            ItemImpl(Items.LINGERING_POTION),
            ItemImpl(Items.EXPERIENCE_BOTTLE),
            ItemImpl(Items.TRIDENT),
            ItemImpl(Items.MILK_BUCKET),
        ),
        subclasses = persistentSetOf(
            ItemFactoryImpl.rangedWeaponSubclass,
            ItemFactoryImpl.armorSubclass,
            ItemFactoryImpl.bundleSubclass,
        ),
        components = persistentListOf(
            FoodComponentImpl,
        )
    )

    override val showCrosshairItems = ItemList(
        whitelist = persistentListOf(
            ItemImpl(Items.EGG),
            ItemImpl(Items.SNOWBALL),
            ItemImpl(Items.SPLASH_POTION),
            ItemImpl(Items.LINGERING_POTION),
            ItemImpl(Items.EXPERIENCE_BOTTLE),
            ItemImpl(Items.TRIDENT),
            ItemImpl(Items.ENDER_PEARL),
        ),
        subclasses = persistentSetOf(
            ItemFactoryImpl.rangedWeaponSubclass,
        )
    )

    override val crosshairAimingItems = ItemList(
        whitelist = persistentListOf(
            ItemImpl(Items.ENDER_EYE),
            ItemImpl(Items.GLASS_BOTTLE),
        ),
        subclasses = persistentSetOf(
            ItemFactoryImpl.bucketSubclass,
            ItemFactoryImpl.boatSubclass,
            ItemFactoryImpl.placeableOnWaterSubclass,
            ItemFactoryImpl.spawnEggSubclass,
        )
    )

    /** 蓄力准星适用的物品。 */
    override val chargeCrosshairItems = ItemList(
        whitelist = persistentListOf(
            ItemImpl(Items.BOW),
            ItemImpl(Items.CROSSBOW),
            ItemImpl(Items.TRIDENT),
        ),
        subclasses = persistentSetOf(
            ItemFactoryImpl.rangedWeaponSubclass,
        ),
    )

    /**
     * 吃饱收手适用的食物。
     * <ul>
     *   <li>组件 = 食物（靠回饥饿值的普通食物）→ 吃饱后默认收手；</li>
     *   <li>黑名单 = 金苹果 / 附魔金苹果（`canAlwaysEat`，吃饱了还能吃）→ 这些不触发收手，
     *       吃饱后仍可继续吃 / 使用。</li>
     * </ul>
     */
    override val eatStopItems = ItemList(
        components = persistentListOf(
            FoodComponentImpl,
        ),
        blacklist = persistentListOf(
            ItemImpl(Items.GOLDEN_APPLE),
            ItemImpl(Items.ENCHANTED_GOLDEN_APPLE),
        ),
    )

    /**
     * 长按改挖方块适用的物品。
     * 默认空清单（全部物品参与长按改判），用户可按需在物品分栏里填白/黑名单。
     * 命中黑名单 = 拿着该物品时长按不挖方块。
     */
    override val longPressDigItems = ItemList()
}