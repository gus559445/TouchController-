package top.fifthlight.touchcontroller.common_1_20_1

import org.koin.dsl.module
import top.fifthlight.combine.data.DataComponentTypeFactory
import top.fifthlight.combine.data.ItemFactory
import top.fifthlight.combine.data.TextFactory
import top.fifthlight.combine.platform_1_20_1.FoodComponentTypeFactoryImpl
import top.fifthlight.combine.platform_1_20_1.ItemFactoryImpl
import top.fifthlight.combine.platform_1_20_1.ScreenFactoryImpl
import top.fifthlight.combine.platform_1_20_1.TextFactoryImpl
import top.fifthlight.combine.screen.ScreenFactory
import top.fifthlight.touchcontroller.common.di.appModule
import top.fifthlight.touchcontroller.common.gal.ChatMessageProvider
import top.fifthlight.touchcontroller.common.gal.DefaultItemListProvider
import top.fifthlight.touchcontroller.common.gal.EntityListProvider
import top.fifthlight.touchcontroller.common.gal.PlayerHandleFactory
import top.fifthlight.touchcontroller.common.gal.TweakState
import top.fifthlight.touchcontroller.common.gal.VanillaItemListProvider
import top.fifthlight.touchcontroller.common_1_20_1.gal.ChatMessageProviderImpl
import top.fifthlight.touchcontroller.common_1_20_1.gal.DefaultItemListProviderImpl
import top.fifthlight.touchcontroller.common_1_20_1.gal.EntityListProviderImpl
import top.fifthlight.touchcontroller.common_1_20_1.gal.PlayerHandleFactoryImpl
import top.fifthlight.touchcontroller.common_1_20_1.gal.TweakStateProviderImpl
import top.fifthlight.touchcontroller.common_1_20_1.gal.VanillaItemListProviderImpl
import top.fifthlight.touchcontroller.common_1_20_x.platformModule

val versionModule = module {
    includes(
        platformModule,
        appModule,
    )
    single<ItemFactory> { ItemFactoryImpl }
    single<TextFactory> { TextFactoryImpl }
    single<DataComponentTypeFactory> { FoodComponentTypeFactoryImpl }
    single<ScreenFactory> { ScreenFactoryImpl }
    single<PlayerHandleFactory> { PlayerHandleFactoryImpl }
    single<DefaultItemListProvider> { DefaultItemListProviderImpl }
    single<VanillaItemListProvider> { VanillaItemListProviderImpl }
    single<ChatMessageProvider> { ChatMessageProviderImpl }
    // 实体列表（「骑乘 / 瞄准指定实体」条件选择列表用）：ID + 游戏内显示名。
    single<EntityListProvider> { EntityListProviderImpl }
    // 1.20.1 上把「增强功能」需要的玩家状态判定换成真实实现（common 层默认是空实现）。
    // 模块加载时执行一次，比多注册一份 Koin 定义省事，也不用碰同类型定义覆盖的规则。
    TweakState.provider = TweakStateProviderImpl
}
