package top.fifthlight.touchcontroller.common_1_20_1.gal

import kotlinx.collections.immutable.toPersistentList
import net.minecraft.client.Minecraft
import net.minecraft.client.player.LocalPlayer
import net.minecraft.world.InteractionHand
import net.minecraft.world.entity.animal.Pig
import net.minecraft.world.entity.animal.camel.Camel
import net.minecraft.world.entity.animal.horse.*
import net.minecraft.world.entity.monster.Strider
import net.minecraft.world.entity.vehicle.Boat
import net.minecraft.world.entity.vehicle.Minecart
import top.fifthlight.combine.data.Identifier
import top.fifthlight.combine.data.Item
import top.fifthlight.combine.data.ItemStack
import top.fifthlight.combine.platform_1_20_1.ItemStackImpl
import top.fifthlight.combine.platform_1_20_1.toCombine
import top.fifthlight.touchcontroller.common.config.ItemList
import top.fifthlight.touchcontroller.common.gal.PlayerHandle
import top.fifthlight.touchcontroller.common.gal.PlayerHandleFactory
import top.fifthlight.touchcontroller.common.gal.PlayerInventory
import top.fifthlight.touchcontroller.common.gal.RidingEntityType
import top.fifthlight.touchcontroller.common_1_20_x.gal.AbstractPlayerHandleImpl
import net.minecraft.core.registries.BuiltInRegistries
import kotlinx.collections.immutable.PersistentList
import kotlinx.collections.immutable.persistentListOf
import java.util.Optional
import org.slf4j.LoggerFactory

private val LOGGER = LoggerFactory.getLogger("TC-Curios")

class PlayerHandleImpl(inner: LocalPlayer) : AbstractPlayerHandleImpl(inner) {
    override fun hasItemsOnHand(list: ItemList): Boolean = InteractionHand.entries.any { hand ->
        inner.getItemInHand(hand).toCombine().item in list
    }

    override fun matchesItemOnHand(item: Item): Boolean = InteractionHand.entries.any { hand ->
        item.matches(inner.getItemInHand(hand).toCombine().item)
    }

    override fun getInventorySlot(index: Int): ItemStack = ItemStackImpl(inner.inventory.getItem(index))

    override fun getInventory() = PlayerInventory(
        main = inner.inventory.items.map { it.toCombine() }.toPersistentList(),
        armor = inner.inventory.armor.map { it.toCombine() }.toPersistentList(),
        offHand = inner.inventory.offhand.first().toCombine(),
        curios = collectCuriosItems(),
    )

    /**
     * 反射读取 Curios API 的全部饰品槽物品（软依赖：未安装 Curios 时静默返回空列表）。
     * 覆盖暮色森林（护身符/灯/皇冠等）、天境（戒指/披风/手套等）以及其他任何走 Curios 的模组饰品。
     *
     * 调用链（基于 curios-forge-5.14.1+1.20.1 实际字节码确认）：
     *   CuriosApi.getCuriosInventory(LivingEntity) -> LazyOptional<ICuriosItemHandler>
     *   .resolve() -> Optional<ICuriosItemHandler>
     *   ICuriosItemHandler.getSlots() -> IItemHandlerModifiable  （整个饰品栏）
     *   IItemHandler.getSlots() -> int
     *   IItemHandler.getStackInSlot(i) -> ItemStack
     */
    private fun collectCuriosItems(): PersistentList<ItemStack> {
        return try {
            // 1. CuriosApi.getCuriosInventory(LivingEntity) -> LazyOptional<ICuriosItemHandler>
            val curiosApiCls = Class.forName("top.theillusivec4.curios.api.CuriosApi")
            val getInvMethod = curiosApiCls.getMethod(
                "getCuriosInventory",
                net.minecraft.world.entity.LivingEntity::class.java,
            )
            val lazyOptional = getInvMethod.invoke(null, inner) ?: return persistentListOf()

            // 2. LazyOptional.resolve() -> Optional<ICuriosItemHandler>
            val resolved = if (lazyOptional is Optional<*>) {
                lazyOptional
            } else {
                val resolveMethod = lazyOptional.javaClass.methods.firstOrNull {
                    it.name == "resolve" && it.parameterCount == 0
                } ?: return persistentListOf()
                resolveMethod.invoke(lazyOptional) as? Optional<*> ?: return persistentListOf()
            }
            val handler = resolved.orElse(null) ?: return persistentListOf()

            // 3. ICuriosItemHandler.getEquippedCurios() -> IItemHandlerModifiable（整个饰品栏）
            //    （字节码确认：返回 IItemHandlerModifiable 的方法是 getEquippedCurios，不是 getSlots）
            val getEquipped = handler.javaClass.methods.firstOrNull { m ->
                m.name == "getEquippedCurios" && m.parameterCount == 0
            } ?: return persistentListOf()
            val itemHandler = getEquipped.invoke(handler) ?: return persistentListOf()

            // 4. IItemHandler.getSlots() -> int
            val slotCount = (itemHandler.javaClass.methods.firstOrNull { m ->
                m.name == "getSlots" && m.parameterCount == 0
            }?.invoke(itemHandler) as? Int) ?: return persistentListOf()

            // 5. IItemHandler.getStackInSlot(i) -> ItemStack
            val getStackMethod = itemHandler.javaClass.methods.firstOrNull { m ->
                m.name == "getStackInSlot" && m.parameterCount == 1
            } ?: return persistentListOf()

            val result = ArrayList<ItemStack>(slotCount)
            for (i in 0 until slotCount) {
                val stack = getStackMethod.invoke(itemHandler, i) as? net.minecraft.world.item.ItemStack
                if (stack != null && !stack.isEmpty) {
                    result.add(stack.toCombine())
                }
            }
            LOGGER.info("[TC-Curios] read ${result.size} curios from ${slotCount} slots")
            result.toPersistentList()
        } catch (t: Throwable) {
            // 未安装 Curios 或 API 变动：静默跳过，不影响原版护甲检测
            LOGGER.warn("[TC-Curios] collectCuriosItems failed: ${t.javaClass.name}: ${t.message}")
            persistentListOf()
        }
    }

    override val ridingEntityType: RidingEntityType?
        get() = when (inner.vehicle) {
            null -> null
            is Minecart -> RidingEntityType.MINECART
            is Boat -> RidingEntityType.BOAT
            is Pig -> RidingEntityType.PIG
            is Camel -> RidingEntityType.CAMEL
            is Horse, is Donkey, is Mule, is ZombieHorse, is SkeletonHorse -> RidingEntityType.HORSE
            is Llama -> RidingEntityType.LLAMA
            is Strider -> RidingEntityType.STRIDER
            else -> RidingEntityType.OTHER
        }

    override val ridingEntityId: Identifier?
        get() = inner.vehicle?.let { vehicle ->
            val rl = BuiltInRegistries.ENTITY_TYPE.getKey(vehicle.type)
            Identifier("${rl.namespace}:${rl.path}")
        }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as PlayerHandleImpl

        return inner == other.inner
    }

    override fun hashCode(): Int = inner.hashCode()

    /**
     * 手上（主手或副手）拿着的食物属于传入清单吗。
     * 清单为空时全部食物放行（和 [hasItemsOnHand] 的「空 = 全放行」语义对齐）。
     */
    override fun hasFoodOnHand(list: ItemList): Boolean = InteractionHand.entries.any { hand ->
        val stack = inner.getItemInHand(hand)
        if (stack.isEmpty) return@any false
        val item = stack.toCombine().item
        // 非食物直接跳过，避免把弓/盾等非食物误判进清单。
        if (stack.item.getFoodProperties() == null) return@any false
        // 清单语义：空清单 → 放行；否则 ItemList.contains 内置「黑名单优先」。
        if (list.whitelist.isEmpty() && list.blacklist.isEmpty()) {
            return@any true
        }
        item in list
    }
}

object PlayerHandleFactoryImpl : PlayerHandleFactory {
    private val client = Minecraft.getInstance()

    override fun getPlayerHandle(): PlayerHandle? = client.player?.let(::PlayerHandleImpl)
}