package top.fifthlight.touchcontroller.common_1_20_1.gal

import kotlinx.collections.immutable.toPersistentList
import net.minecraft.client.Minecraft
import net.minecraft.client.player.LocalPlayer
import net.minecraft.world.InteractionHand
import net.minecraft.world.entity.animal.Pig
import net.minecraft.world.entity.animal.camel.Camel
import net.minecraft.world.entity.animal.horse.*
import net.minecraft.world.entity.monster.Strider
import net.minecraft.world.entity.vehicle.Boat
import net.minecraft.world.entity.vehicle.Minecart
import top.fifthlight.combine.data.Identifier
import top.fifthlight.combine.data.Item
import top.fifthlight.combine.data.ItemStack
import top.fifthlight.combine.platform_1_20_1.ItemStackImpl
import top.fifthlight.combine.platform_1_20_1.toCombine
import top.fifthlight.touchcontroller.common.config.ItemList
import top.fifthlight.touchcontroller.common.gal.PlayerHandle
import top.fifthlight.touchcontroller.common.gal.PlayerHandleFactory
import top.fifthlight.touchcontroller.common.gal.PlayerInventory
import top.fifthlight.touchcontroller.common.gal.RidingEntityType
import top.fifthlight.touchcontroller.common_1_20_x.gal.AbstractPlayerHandleImpl
import net.minecraft.core.registries.BuiltInRegistries
import kotlinx.collections.immutable.PersistentList
import kotlinx.collections.immutable.persistentListOf
import java.util.Optional
import org.slf4j.LoggerFactory

private val LOGGER = LoggerFactory.getLogger("TC-Curios")

class PlayerHandleImpl(inner: LocalPlayer) : AbstractPlayerHandleImpl(inner) {
    override fun hasItemsOnHand(list: ItemList): Boolean = InteractionHand.entries.any { hand ->
        inner.getItemInHand(hand).toCombine().item in list
    }

    override fun matchesItemOnHand(item: Item): Boolean = InteractionHand.entries.any { hand ->
        item.matches(inner.getItemInHand(hand).toCombine().item)
    }

    override fun getInventorySlot(index: Int): ItemStack = ItemStackImpl(inner.inventory.getItem(index))

    override fun getInventory() = PlayerInventory(
        main = inner.inventory.items.map { it.toCombine() }.toPersistentList(),
        armor = inner.inventory.armor.map { it.toCombine() }.toPersistentList(),
        offHand = inner.inventory.offhand.first().toCombine(),
        curios = collectCuriosItems(),
    )

    /**
     * 反射读取 Curios API 的全部饰品槽物品（软依赖：未安装 Curios 时静默返回空列表）。
     * 覆盖暮色森林（护身符/灯/皇冠等）、天境（戒指/披风/手套等）以及其他任何走 Curios 的模组饰品。
     *
     * 调用链（基于 curios-forge-5.14.1+1.20.1 实际字节码确认）：
     *   CuriosApi.getCuriosInventory(LivingEntity) -> LazyOptional<ICuriosItemHandler>
     *   .resolve() -> Optional<ICuriosItemHandler>
     *   ICuriosItemHandler.getSlots() -> IItemHandlerModifiable  （整个饰品栏）
     *   IItemHandler.getSlots() -> int
     *   IItemHandler.getStackInSlot(i) -> ItemStack
     */
    private fun collectCuriosItems(): PersistentList<ItemStack> {
        return try {
            // 1. CuriosApi.getCuriosInventory(LivingEntity) -> LazyOptional<ICuriosItemHandler>
            val curiosApiCls = Class.forName("top.theillusivec4.curios.api.CuriosApi")
            val getInvMethod = curiosApiCls.getMethod(
                "getCuriosInventory",
                net.minecraft.world.entity.LivingEntity::class.java,
            )
            val lazyOptional = getInvMethod.invoke(null, inner) ?: return persistentListOf()

            // 2. LazyOptional.resolve() -> Optional<ICuriosItemHandler>
            val resolved = if (lazyOptional is Optional<*>) {
                lazyOptional
            } else {
                val resolveMethod = lazyOptional.javaClass.methods.firstOrNull {
                    it.name == "resolve" && it.parameterCount == 0
                } ?: return persistentListOf()
                resolveMethod.invoke(lazyOptional) as? Optional<*> ?: return persistentListOf()
            }
            val handler = resolved.orElse(null) ?: return persistentListOf()

            // 3. ICuriosItemHandler.getEquippedCurios() -> IItemHandlerModifiable（整个饰品栏）
            //    （字节码确认：返回 IItemHandlerModifiable 的方法是 getEquippedCurios，不是 getSlots）
            val getEquipped = handler.javaClass.methods.firstOrNull { m ->
                m.name == "getEquippedCurios" && m.parameterCount == 0
            } ?: return persistentListOf()
            val itemHandler = getEquipped.invoke(handler) ?: return persistentListOf()

            // 4. IItemHandler.getSlots() -> int
            val slotCount = (itemHandler.javaClass.methods.firstOrNull { m ->
                m.name == "getSlots" && m.parameterCount == 0
            }?.invoke(itemHandler) as? Int) ?: return persistentListOf()

            // 5. IItemHandler.getStackInSlot(i) -> ItemStack
            val getStackMethod = itemHandler.javaClass.methods.firstOrNull { m ->
                m.name == "getStackInSlot" && m.parameterCount == 1
            } ?: return persistentListOf()

            val result = ArrayList<ItemStack>(slotCount)
            for (i in 0 until slotCount) {
                val stack = getStackMethod.invoke(itemHandler, i) as? net.minecraft.world.item.ItemStack
                if (stack != null && !stack.isEmpty) {
                    result.add(stack.toCombine())
                }
            }
            LOGGER.info("[TC-Curios] read ${result.size} curios from ${slotCount} slots")
            result.toPersistentList()
        } catch (t: Throwable) {
            // 未安装 Curios 或 API 变动：静默跳过，不影响原版护甲检测
            LOGGER.warn("[TC-Curios] collectCuriosItems failed: ${t.javaClass.name}: ${t.message}")
            persistentListOf()
        }
    }

    override val ridingEntityType: RidingEntityType?
        get() = when (inner.vehicle) {
            null -> null
            is Minecart -> RidingEntityType.MINECART
            is Boat -> RidingEntityType.BOAT
            is Pig -> RidingEntityType.PIG
            is Camel -> RidingEntityType.CAMEL
            is Horse, is Donkey, is Mule, is ZombieHorse, is SkeletonHorse -> RidingEntityType.HORSE
            is Llama -> RidingEntityType.LLAMA
            is Strider -> RidingEntityType.STRIDER
            else -> RidingEntityType.OTHER
        }

    override val ridingEntityId: Identifier?
        get() = inner.vehicle?.let { vehicle ->
            val rl = BuiltInRegistries.ENTITY_TYPE.getKey(vehicle.type)
            Identifier("${rl.namespace}:${rl.path}")
        }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as PlayerHandleImpl

        return inner == other.inner
    }

    override fun hashCode(): Int = inner.hashCode()

    /**
     * 手上（主手或副手）拿着的食物属于传入清单吗（吃饱收手用）。
     *
     * <p>语义（和 [TweakStateProviderImpl] 的 matches 对齐）：</p>
     * <ul>
     *   <li>全空清单 → 全部食物放行（true，原行为）；</li>
     *   <li>命中<b>黑名单</b> → <b>不收手</b>（返回 false，这一口吃饱后仍可继续用）；</li>
     *   <li>命中白名单/组件/子成分 → 收手（true）；</li>
     *   <li>填了白名单/组件/子成分但手上一件没命中 → 不收手（false）；</li>
     *   <li>只填了黑名单且没命中 → 视为「没被排除」，仍然收手（true）。</li>
     * </ul>
     * 只查「食物」：手里非食物（弓/盾/方块等）一律跳过，避免误判。
     */
    override fun hasFoodOnHand(list: ItemList): Boolean {
        val main = inner.getItemInHand(InteractionHand.MAIN_HAND)
        val off = inner.getItemInHand(InteractionHand.OFF_HAND)
        // 全空清单 → 全放行（只要手里有任意食物即视为命中，维持原行为）。
        if (list.whitelist.isEmpty() && list.blacklist.isEmpty() &&
            list.components.isEmpty() && list.subclasses.isEmpty()
        ) {
            return isFood(main) || isFood(off)
        }
        // 命中黑名单 → 不收手（返回 false，这一口吃饱后仍可继续用）。
        if (isBlacklisted(list, main) || isBlacklisted(list, off)) {
            return false
        }
        // 命中白名单/组件/子成分 → 收手（true）。
        if (isListed(list, main) || isListed(list, off)) {
            return true
        }
        // 全部未命中：
        // 若填了白名单/组件/子成分 → 不收手（false）；
        // 若只填了黑名单且没命中 → 视为「没被排除」，仍然收手（true）。
        if (list.whitelist.isNotEmpty() || list.components.isNotEmpty() || list.subclasses.isNotEmpty()) {
            return false
        }
        return isFood(main) || isFood(off)
    }
    private fun isFood(stack: net.minecraft.world.item.ItemStack): Boolean =
        !stack.isEmpty && stack.item.getFoodProperties() != null

    private fun isBlacklisted(list: ItemList, stack: net.minecraft.world.item.ItemStack): Boolean {
        if (stack.isEmpty) return false
        val item = stack.toCombine().item
        return list.blacklist.any { it.matches(item) }
    }

    private fun isListed(list: ItemList, stack: net.minecraft.world.item.ItemStack): Boolean {
        if (stack.isEmpty) return false
        val item = stack.toCombine().item
        if (list.whitelist.any { it.matches(item) }) return true
        if (list.components.any { item.containComponents(it) }) return true
        if (list.subclasses.any { item.isSubclassOf(it) }) return true
        return false
    }
}

object PlayerHandleFactoryImpl : PlayerHandleFactory {
    private val client = Minecraft.getInstance()

    override fun getPlayerHandle(): PlayerHandle? = client.player?.let(::PlayerHandleImpl)
}