package top.fifthlight.touchcontroller.common_1_20_1.gal

import net.minecraft.client.Minecraft
import net.minecraft.world.entity.Entity
import net.minecraft.world.entity.EntityType
import net.minecraft.world.entity.LivingEntity
import net.minecraft.world.entity.animal.Cat
import net.minecraft.world.entity.animal.Parrot
import net.minecraft.world.entity.animal.Sheep
import net.minecraft.world.entity.animal.Wolf
import net.minecraft.world.entity.animal.horse.AbstractHorse
import net.minecraft.world.entity.npc.Villager
import net.minecraft.world.item.DyeColor

/**
 * 实体「状态」：给「瞄准指定实体」条件用，可以只对「驯服的坐着的狼」「躺着的村民」「白羊」生效。
 *
 * <p>状态用字符串键表示（[currentState] 读实例、[statesFor] 列某类型可选的状态），
 * 两边必须一一对应，否则条件永远匹配不上：
 * <ul>
 *   <li>幼年 / 成年：`baby` / `adult`——只要这个生物类重写了 {@code isBaby()}
 *       （原版的牛羊猪鸡、村民、僵尸、猪灵……以及模组里自己加的幼年生物）就有这一维</li>
 *   <li>狼 / 猫 / 鹦鹉：`wild`（野生）、`tamed_standing`（驯服站着）、`tamed_sitting`（驯服坐着，
 *       猫还有 `tamed_lying`）</li>
 *   <li>马 / 驴 / 骡：`wild`、`tamed`</li>
 *   <li>村民：`standing` / `sleeping`</li>
 *   <li>羊：`color:&lt;颜色名&gt;`（16 种）</li>
 * </ul></p>
 *
 * <p>幼年优先：幼年个体一律返回 `baby`，不管它还有没有别的维度（幼年狼就是 `baby`）。
 * 反过来，已经有别的状态维度的类（狼、羊…）就只额外给一条 `baby`，
 * 不给 `adult`——成年个体仍然用它们原来的那些状态，多出来的 `adult` 永远匹配不上。</p>
 */
object EntityStateHelper {

    /** 读实体实例当前的状态键；没有状态维度的实体返回 null。 */
    fun currentState(entity: Entity): String? {
        if (entity is LivingEntity) {
            if (entity.isBaby) {
                return "baby"
            }
            // 这一类有幼年形态、但这一只已经成年：只有在它没有别的状态维度时才报 `adult`，
            // 否则「成年的坐着的狼」这种组合没法表达，报 adult 会把原来的 wild/tamed 顶掉。
            if (canBeBaby(entity.javaClass) && baseStatesOf(entity) == null) {
                return "adult"
            }
        }
        return baseStatesOf(entity)
    }

    /** 某实体类型可选的状态列表（状态键 to 中文名）；没有状态维度就返回空表。 */
    fun statesFor(type: EntityType<*>): List<Pair<String, String>> {
        val base = baseStatesFor(type)
        val cls = entityClassOf(type)
        if (cls == null || !canBeBaby(cls)) {
            return base
        }
        // 没有别的状态维度：幼年 / 成年正好把这一类分完，两条都给。
        // 已经有别的维度（狼、羊、村民…）：只加幼年，成年走原来的状态。
        return if (base.isEmpty()) {
            listOf("baby" to "幼年", "adult" to "成年")
        } else {
            base + ("baby" to "幼年")
        }
    }

    /**
     * 这个类有没有幼年形态。
     *
     * <p>判断依据是「它自己重写了 isBaby()」：原版 {@code LivingEntity.isBaby()} 永远返回 false，
     * 牛羊村民僵尸猪灵这些都各自覆盖成读数据参数，模组生物同理。
     * 这样不用维护类型白名单，模组里加的幼年生物自动就在列表里。</p>
     *
     * <p>结果按类缓存：[currentState] 每帧都会调，反射 getMethod 不该反复做。</p>
     */
    private fun canBeBaby(cls: Class<*>): Boolean = babyCache.getOrPut(cls) {
        LivingEntity::class.java.isAssignableFrom(cls) &&
            runCatching { cls.getMethod("isBaby").declaringClass }.getOrNull() != LivingEntity::class.java
    }

    private val babyCache = HashMap<Class<*>, Boolean>()

    /** 拿 EntityType 对应的实体类；创建不出来（玩家、掉落物之类）就当没有。 */
    private fun entityClassOf(type: EntityType<*>): Class<*>? =
        runCatching { type.create(Minecraft.getInstance().level) }.getOrNull()?.javaClass

    /** 实例的原生状态（不含幼年这一维）。 */
    private fun baseStatesOf(entity: Entity): String? = when (entity) {
        is Wolf -> when {
            !entity.isTame -> "wild"
            entity.isInSittingPose -> "tamed_sitting"
            else -> "tamed_standing"
        }

        is Cat -> when {
            !entity.isTame -> "wild"
            entity.isInSittingPose -> "tamed_sitting"
            entity.isLying -> "tamed_lying"
            else -> "tamed_standing"
        }

        is Parrot -> if (entity.isTame) "tamed" else "wild"
        is AbstractHorse -> if (entity.isTamed) "tamed" else "wild"
        is Villager -> if (entity.isSleeping) "sleeping" else "standing"
        is Sheep -> "color:${entity.color.serializedName}"
        else -> null
    }

    /** 类型层面的原生状态表（不含幼年这一维）。 */
    private fun baseStatesFor(type: EntityType<*>): List<Pair<String, String>> = when (type) {
        EntityType.WOLF -> listOf(
            "wild" to "野生",
            "tamed_standing" to "驯服·站着",
            "tamed_sitting" to "驯服·坐着",
        )

        EntityType.CAT -> listOf(
            "wild" to "野生",
            "tamed_standing" to "驯服·站着",
            "tamed_sitting" to "驯服·坐着",
            "tamed_lying" to "驯服·趴着",
        )

        EntityType.PARROT,
        EntityType.HORSE,
        EntityType.DONKEY,
        EntityType.MULE,
        EntityType.SKELETON_HORSE,
        EntityType.ZOMBIE_HORSE,
        -> listOf("wild" to "野生", "tamed" to "驯服")

        EntityType.VILLAGER -> listOf("standing" to "站着", "sleeping" to "躺着")

        EntityType.SHEEP -> DyeColor.entries.map { color ->
            "color:${color.serializedName}" to colorName(color)
        }

        else -> emptyList()
    }

    private fun colorName(color: DyeColor): String = when (color) {
        DyeColor.WHITE -> "白"
        DyeColor.ORANGE -> "橙"
        DyeColor.MAGENTA -> "品红"
        DyeColor.LIGHT_BLUE -> "淡蓝"
        DyeColor.YELLOW -> "黄"
        DyeColor.LIME -> "黄绿"
        DyeColor.PINK -> "粉"
        DyeColor.GRAY -> "灰"
        DyeColor.LIGHT_GRAY -> "淡灰"
        DyeColor.CYAN -> "青"
        DyeColor.PURPLE -> "紫"
        DyeColor.BLUE -> "蓝"
        DyeColor.BROWN -> "棕"
        DyeColor.GREEN -> "绿"
        DyeColor.RED -> "红"
        DyeColor.BLACK -> "黑"
    }
}
