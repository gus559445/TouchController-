package top.fifthlight.touchcontroller.common_1_20_1.gal

import net.minecraft.world.entity.Entity
import net.minecraft.world.entity.EntityType
import net.minecraft.world.entity.animal.Cat
import net.minecraft.world.entity.animal.Sheep
import net.minecraft.world.entity.animal.Wolf
import net.minecraft.world.entity.npc.Villager
import net.minecraft.world.item.DyeColor

/**
 * 实体「状态」：给「瞄准指定实体」条件用，可以只对「坐着的狼」「躺着的村民」「白羊」生效。
 *
 * <p>状态用字符串键表示（[currentState] 读实例、[statesFor] 列某类型可选的状态），
 * 两边必须一一对应，否则条件永远匹配不上：
 * <ul>
 *   <li>狼 / 猫：`standing` / `sitting`（猫还有 `lying`）</li>
 *   <li>村民：`standing` / `sleeping`</li>
 *   <li>羊：`color:&lt;颜色名&gt;`（16 种）</li>
 * </ul></p>
 */
object EntityStateHelper {

    /** 读实体实例当前的状态键；没有状态维度的实体返回 null。 */
    fun currentState(entity: Entity): String? = when (entity) {
        is Wolf -> if (entity.isInSittingPose) "sitting" else "standing"
        is Cat -> when {
            entity.isInSittingPose -> "sitting"
            entity.isLying -> "lying"
            else -> "standing"
        }

        is Villager -> if (entity.isSleeping) "sleeping" else "standing"
        is Sheep -> "color:${entity.color.serializedName}"
        else -> null
    }

    /** 某实体类型可选的状态列表（状态键 to 中文名）；没有状态维度就返回空表。 */
    fun statesFor(type: EntityType<*>): List<Pair<String, String>> = when (type) {
        EntityType.WOLF -> listOf("standing" to "站着", "sitting" to "坐着")
        EntityType.CAT -> listOf("standing" to "站着", "sitting" to "坐着", "lying" to "趴着")
        EntityType.VILLAGER -> listOf("standing" to "站着", "sleeping" to "躺着")
        EntityType.SHEEP -> DyeColor.entries.map { color ->
            "color:${color.serializedName}" to colorName(color)
        }

        else -> emptyList()
    }

    private fun colorName(color: DyeColor): String = when (color) {
        DyeColor.WHITE -> "白"
        DyeColor.ORANGE -> "橙"
        DyeColor.MAGENTA -> "品红"
        DyeColor.LIGHT_BLUE -> "淡蓝"
        DyeColor.YELLOW -> "黄"
        DyeColor.LIME -> "黄绿"
        DyeColor.PINK -> "粉"
        DyeColor.GRAY -> "灰"
        DyeColor.LIGHT_GRAY -> "淡灰"
        DyeColor.CYAN -> "青"
        DyeColor.PURPLE -> "紫"
        DyeColor.BLUE -> "蓝"
        DyeColor.BROWN -> "棕"
        DyeColor.GREEN -> "绿"
        DyeColor.RED -> "红"
        DyeColor.BLACK -> "黑"
    }
}
