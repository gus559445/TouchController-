package top.fifthlight.touchcontroller.common_1_20_1.gal

import net.minecraft.world.item.ItemStack
import net.minecraft.world.item.ShieldItem
import net.minecraftforge.common.ToolActions
import top.fifthlight.combine.platform_1_20_1.ItemImpl
import top.fifthlight.touchcontroller.common.config.ItemList

/**
 * 「这个物品算不算盾牌」的唯一判定入口。
 *
 * <p>三条来源，命中任意一条就算盾牌：</p>
 * <ol>
 *   <li>原版盾类（{@link ShieldItem}）；</li>
 *   <li>Forge 标准钩子：能执行 {@code SHIELD_BLOCK} 动作（模组盾基本都是这么声明的）；</li>
 *   <li>玩家在「物品 → 盾牌」里的白名单——有些模组道具只是长得像盾、或者想借用潜行举盾的手感，
 *       不一定真的注册了格挡动作，那就由玩家点名。</li>
 * </ol>
 *
 * <p>白名单由配置层每帧推过来（[update]），因为这个判定在 Mixin 里也要用，
 * 那边拿不到 Koin 容器。</p>
 */
object ShieldWhitelist {
    @Volatile
    private var items: ItemList = ItemList()

    /** 配置改动后推一次（每帧推也无所谓，赋值本身很便宜）。 */
    fun update(list: ItemList) {
        items = list
    }

    /** [stack] 算不算盾牌。 */
    fun matches(stack: ItemStack?): Boolean {
        if (stack == null || stack.isEmpty) {
            return false
        }
        if (stack.item is ShieldItem) {
            return true
        }
        if (stack.canPerformAction(ToolActions.SHIELD_BLOCK)) {
            return true
        }
        return ItemImpl(stack.item) in items
    }
}
