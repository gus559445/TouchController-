package top.fifthlight.touchcontroller.common_1_20_1.gal

import net.minecraft.client.Minecraft
import net.minecraft.client.player.LocalPlayer
import net.minecraft.world.entity.player.Player
import net.minecraft.world.item.BowItem
import net.minecraft.world.item.CrossbowItem
import net.minecraft.world.item.ItemStack
import net.minecraft.world.item.Items
import net.minecraft.world.item.UseAnim
import top.fifthlight.combine.platform_1_20_1.toCombine
import top.fifthlight.touchcontroller.common.config.ItemList
import top.fifthlight.touchcontroller.common.gal.TweakStateProvider

/**
 * 1.20.1 上「增强功能」需要的玩家状态判定（蓄力准星 / 潜行举盾共用）。
 *
 * 只读本地玩家当前的状态，不修改任何东西，每渲染帧被问一次，开销可以忽略。
 */
object TweakStateProviderImpl : TweakStateProvider {
    private val client
        get() = Minecraft.getInstance()

    /**
     * 主手或副手拿着可蓄力的武器：弓（BOW）、弩（CROSSBOW）、三叉戟这类投掷（SPEAR）。
     * 用使用动画判断而不是逐个登记物品 id，模组武器只要照抄原版机制就自动生效。
     */
    override fun holdsChargeableItem(): Boolean {
        val player = client.player ?: return false
        return isChargeable(player.mainHandItem) || isChargeable(player.offhandItem)
    }

    /**
     * 正在使用「蓄力类使用动画」的物品：弓（BOW）、弩（CROSSBOW）、三叉戟这类投掷（SPEAR）。
     */
    override fun isChargingChargeableItem(): Boolean {
        val player = client.player ?: return false
        if (!player.isUsingItem) {
            return false
        }
        return isChargeable(player.useItem)
    }

    /**
     * 主手或副手有「装弹完成」的弩：弦已上好、弹药就位，一按就能射。
     * 用原版记在物品上的 Charged 标记判断，照抄这套机制的模组弩也能认出来。
     */
    override fun hasLoadedCrossbow(): Boolean {
        val player = client.player ?: return false
        return isLoadedCrossbow(player.mainHandItem) || isLoadedCrossbow(player.offhandItem)
    }

    /** 主手或副手拿着盾牌。原版盾用物品 id 认，模组盾只要照抄原版的 BLOCK 使用动画也能认出来。 */
    override fun hasShieldOnHand(): Boolean {
        val player = client.player ?: return false
        return isShield(player.mainHandItem) || isShield(player.offhandItem)
    }

    /**
     * 手上（主手或副手）的东西此刻能不能真的用出去。
     *
     * 只有食物和原版弓弩是能提前预判的：吃饱了吃不下、弓弩没弹药也没上弦，就是确定用不出去；
     * 其他物品（模组枪械等）返回 true，交给 View 里「长按 0.3 秒还没开始使用」的兜底规则。
     */
    override fun canUseHeldItemNow(): Boolean {
        val player = client.player ?: return true
        val main = judgeHand(player, player.mainHandItem)
        val off = judgeHand(player, player.offhandItem)
        // 一只手确定用不出去、另一只手也没有「现在就能用」的东西 → 整体算用不出去。
        // 另一只手明确能用（比如副手拿着上膛的弩）时，就不要去打断它。
        if (main == false && off != true) {
            return false
        }
        if (off == false && main != true) {
            return false
        }
        return true
    }

    /** 正在吃（使用动画是 EAT 的物品：面包、熟肉这些）。拿着不算。 */
    override fun isEatingFood(): Boolean {
        val player = client.player ?: return false
        if (!player.isUsingItem) {
            return false
        }
        return player.useItem.useAnimation == UseAnim.EAT
    }

    /** 正在吃的这一口是「靠回饥饿值」的普通食物，而不是金苹果这类满饥饿也能吃的。 */
    override fun isEatingFillingFood(): Boolean {
        val player = client.player ?: return false
        if (!player.isUsingItem) {
            return false
        }
        val stack = player.useItem
        if (stack.isEmpty || stack.useAnimation != UseAnim.EAT) {
            return false
        }
        val food = stack.item.getFoodProperties() ?: return false
        return food.nutrition > 0 && !food.canAlwaysEat()
    }

    /** 饥饿值是不是已经到顶（10 颗心 = 20 点）。 */
    override fun isFoodLevelFull(): Boolean {
        val player = client.player ?: return false
        return player.foodData.foodLevel >= 20
    }

    /**
     * 这只手的物品是不是「现在就能用出去」：
     * `null` 表示不适用（空手、不是食物/弓弩，交给 0.3 秒兜底）。
     */
    private fun judgeHand(player: LocalPlayer, stack: ItemStack): Boolean? {
        if (stack.isEmpty) {
            return null
        }
        if (stack.isEdible) {
            val food = stack.item.getFoodProperties()
            val alwaysEdible = food != null && food.canAlwaysEat()
            // 原版 Item#use 的判定：canEat 为 false 时进食根本不开始。
            return player.canEat(alwaysEdible)
        }
        if (stack.item is CrossbowItem) {
            return CrossbowItem.isCharged(stack) || hasRangedAmmo(player, stack)
        }
        if (stack.item is BowItem) {
            return hasRangedAmmo(player, stack)
        }
        return null
    }

    /** 背包里有没有能喂给这把弓/弩的弹药；创造模式不用弹药也能拉弓上弦。 */
    private fun hasRangedAmmo(player: Player, stack: ItemStack): Boolean {
        return player.abilities.instabuild || !player.getProjectile(stack).isEmpty
    }

    private fun isChargeable(stack: ItemStack): Boolean {
        if (stack.isEmpty) {
            return false
        }
        return when (stack.useAnimation) {
            UseAnim.BOW, UseAnim.CROSSBOW, UseAnim.SPEAR -> true
            else -> false
        }
    }

    private fun isLoadedCrossbow(stack: ItemStack): Boolean {
        if (stack.isEmpty) {
            return false
        }
        val crossbowLike = stack.item is CrossbowItem || stack.useAnimation == UseAnim.CROSSBOW
        return crossbowLike && CrossbowItem.isCharged(stack)
    }

    private fun isShield(stack: ItemStack): Boolean {
        if (stack.isEmpty) {
            return false
        }
        return stack.item == Items.SHIELD || stack.useAnimation == UseAnim.BLOCK
    }

    /**
     * 清单匹配（吃饱收手 / 蓄力准星共用的白名单 + 黑名单判定）。
     *
     * <p>语义按「功能用途」分两种，由调用方按 [list] 传进来决定：</p>
     * <ul>
     *   <li><b>吃饱收手</b>（[isEatingFoodIn]）：命中<b>黑名单</b> = 这口食物吃饱后仍可继续用，
     *       <b>不收手</b>（返回 false，让 EatStopHandler 不触发）。命中白名单/组件/子成分才算命中。</li>
     *   <li><b>蓄力准星</b>（[isChargingItemIn] / [isUsingItemIn] / [holdsLoadedCrossbowIn]）：
     *       命中白名单/组件/子成分才生效（返回 true）；命中黑名单视为不生效。</li>
     * </ul>
     *
     * <p>「全空清单」一律放行（返回 true = 命中），即「什么都没填 = 全部参与」，
     * 和 [top.fifthlight.touchcontroller.common.config.ItemList] 的默认行为对齐。</p>
     */
    private fun matches(list: ItemList, main: ItemStack, off: ItemStack): Boolean {
        val mainItem = main.toCombine().item
        val offItem = off.toCombine().item
        // 全空清单 → 全部放行。
        if (list.whitelist.isEmpty() && list.blacklist.isEmpty() &&
            list.components.isEmpty() && list.subclasses.isEmpty()
        ) {
            return true
        }
        // 黑名单优先（命中黑名单 = 不收手 / 不生效）—— 这是 isEatingFoodIn 的语义。
        if (list.blacklist.any { it.matches(mainItem) }) return false
        if (list.blacklist.any { it.matches(offItem) }) return false
        // 白名单命中。
        if (list.whitelist.any { it.matches(mainItem) }) return true
        if (list.whitelist.any { it.matches(offItem) }) return true
        // 组件命中。
        if (list.components.any { mainItem.containComponents(it) }) return true
        if (list.components.any { offItem.containComponents(it) }) return true
        // 子成分命中。
        if (list.subclasses.any { mainItem.isSubclassOf(it) }) return true
        if (list.subclasses.any { offItem.isSubclassOf(it) }) return true
        // 全部未命中：
        // - 若用户填了白名单但两件手都没命中 → 不收手（返回 false）；
        // - 若用户只填了黑名单且没命中 → 视为「没被排除」，仍然收手（返回 true）。
        if (list.whitelist.isNotEmpty() || list.components.isNotEmpty() || list.subclasses.isNotEmpty()) {
            return false
        }
        return true
    }

    /** 正在吃的那口（[isEatingFood] 为 true 时才有意义）属于传入清单吗。 */
    override fun isEatingFoodIn(list: ItemList): Boolean {
        val player = client.player ?: return false
        if (!player.isUsingItem) {
            return false
        }
        val useItem = player.useItem
        if (useItem.isEmpty || useItem.useAnimation != UseAnim.EAT) {
            return false
        }
        return matches(list, player.mainHandItem, player.offhandItem)
    }

    /** 正在使用的那件可蓄力物品（弓/弩/三叉戟）属于传入清单吗。 */
    override fun isChargingItemIn(list: ItemList): Boolean {
        val player = client.player ?: return false
        if (!player.isUsingItem) {
            return false
        }
        val useItem = player.useItem
        if (!isChargeable(useItem)) {
            return false
        }
        return matches(list, player.mainHandItem, player.offhandItem)
    }

    /** 手上（主手或副手）拿着的已上弦弩属于传入清单吗。 */
    override fun holdsLoadedCrossbowIn(list: ItemList): Boolean {
        val player = client.player ?: return false
        val main = player.mainHandItem
        val off = player.offhandItem
        if (!isLoadedCrossbow(main) && !isLoadedCrossbow(off)) {
            return false
        }
        return matches(list, main, off)
    }

    /** 正在使用的那件物品（吃东西 / 蓄力）属于传入清单吗；不在「使用」状态返回 false。 */
    override fun isUsingItemIn(list: ItemList): Boolean {
        val player = client.player ?: return false
        if (!player.isUsingItem) {
            return false
        }
        val useItem = player.useItem
        if (useItem.isEmpty) {
            return false
        }
        return matches(list, player.mainHandItem, player.offhandItem)
    }
}
