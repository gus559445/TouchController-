package top.fifthlight.touchcontroller.common_1_20_1.gal

import net.minecraft.core.registries.BuiltInRegistries
import top.fifthlight.combine.data.Identifier
import top.fifthlight.touchcontroller.common.gal.EntityListProvider

object EntityListProviderImpl : EntityListProvider {
    override fun getAllEntityTypes(): List<Identifier> =
        BuiltInRegistries.ENTITY_TYPE.keySet()
            .map { resourceLocation ->
                Identifier("${resourceLocation.namespace}:${resourceLocation.path}")
            }
            .sortedBy { it.toString() }
}
