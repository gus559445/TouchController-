package top.fifthlight.touchcontroller.common_1_20_1.gal

import net.minecraft.core.registries.BuiltInRegistries
import top.fifthlight.combine.data.Identifier
import top.fifthlight.touchcontroller.common.gal.EntityEntry
import top.fifthlight.touchcontroller.common.gal.EntityListProvider

object EntityListProviderImpl : EntityListProvider {
    override fun getAllEntities(): List<EntityEntry> =
        BuiltInRegistries.ENTITY_TYPE.keySet()
            .flatMap { resourceLocation ->
                val type = BuiltInRegistries.ENTITY_TYPE.get(resourceLocation)
                    ?: return@flatMap emptyList()
                val id = Identifier("${resourceLocation.namespace}:${resourceLocation.path}")
                // type.description 是可翻译组件，.string 按当前客户端语言解析成实际名字
                val displayName = runCatching { type.description.string }.getOrDefault("")
                val states = EntityStateHelper.statesFor(type)
                if (states.isEmpty()) {
                    listOf(EntityEntry(id = id, displayName = displayName))
                } else {
                    // 狼坐/站、村民躺/站、羊的 16 色：每种状态单独一条，玩家直接选「坐着的狼」。
                    states.map { (key, label) ->
                        EntityEntry(
                            id = id,
                            displayName = displayName,
                            stateKey = key,
                            stateLabel = label,
                        )
                    }
                }
            }
            .sortedWith(compareBy({ it.id.toString() }, { it.stateKey ?: "" }))
}
