package top.fifthlight.touchcontroller.mixin;

import net.minecraft.client.Minecraft;
import org.koin.java.KoinJavaComponent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import top.fifthlight.touchcontroller.common.config.GlobalConfigHolder;
import top.fifthlight.touchcontroller.common.helper.SneakShieldHandler;

/**
 * 潜行举盾：拦截原版的右键（USE）动作入口，实现「禁用右键举盾」。
 *
 * <p>1.20.1 里物理右键按下后由 {@code Minecraft#handleKeybinds()} 检测到「使用键 down」，
 * 调用 {@code Minecraft#startUseItem()} 执行右键动作（放方块 / 开箱子 / 举盾…）。
 * 举盾的链路就是：使用键 down → {@code startUseItem} → {@code MultiPlayerGameMode#useItem}
 * → 盾的 {@code ShieldItem#use} → {@code startUsingItem}。</p>
 *
 * <p>这里在 {@code startUseItem()} 入口拦截：「潜行举盾」开关打开、且盾正举着
 * （[SneakShieldHandler.isShieldUp]）时，吞掉整次右键动作——盾不再被右键举起，
 * 右键通道彻底干净。潜行触发的举盾走版本层 {@code TweakUseExecutor#raiseShield()}
 * （直接 {@code gameMode.useItem}），不经过这个入口，两者互不干扰。
 * 举盾期间触控面板要代执行右键点击时，{@code TweakUseExecutor.performUseClick} 直接调
 * {@code gameMode.useItemOn / useItem}，也不经过这里。</p>
 *
 * <p>语义：「潜行举盾激活（盾举着）」时右键不干活，该干的活由触控面板代执行；
 * 站起来后右键恢复全部原版动作（放方块、开箱子、举盾…）。</p>
 */
@Mixin(Minecraft.class)
public abstract class RightClickShieldGateMixin {
    @Inject(method = "startUseItem()V", at = @At("HEAD"), cancellable = true)
    private void touchController$cancelRightClickShield(CallbackInfo info) {
        Minecraft self = (Minecraft) (Object) this;
        if (self.player == null) {
            return;
        }
        var configHolder = KoinJavaComponent.getOrNull(GlobalConfigHolder.class);
        if (configHolder == null || !configHolder.getConfig().getValue().getTweaks().getSneakShield()) {
            return;
        }
        // 盾正举着才拦截右键；没举着（不潜行）时右键保持原版行为。
        if (SneakShieldHandler.isShieldUp()) {
            info.cancel();
        }
    }
}
