package top.fifthlight.touchcontroller.mixin;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.level.Level;
import org.koin.java.KoinJavaComponent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import top.fifthlight.touchcontroller.common.config.GlobalConfigHolder;
import top.fifthlight.touchcontroller.common.helper.SneakShieldRaiseGate;

/**
 * 潜行举盾：直接拦 {@code ShieldItem#use}（举起盾牌那一刻），实现「禁用右键举盾」。
 *
 * <p>右键（物理或触控模拟）举起盾的链路是：
 * {@code KeyMapping#click/consumeClick → Minecraft#startUseItem → MultiPlayerGameMode#useItem
 * → ItemStack#use → ShieldItem#use → startUsingItem}。
 * 这里在 {@code ShieldItem#use} 入口拦截：「潜行举盾」开关打开时，右键这条路把盾举起来的动作被吞掉，
 * 盾不再被右键举起，举盾只由潜行驱动（版本层 {@code TweakUseExecutor#raiseShield} 直接
 * {@code gameMode.useItem}，并先置 {@link SneakShieldRaiseGate} 的旁路标志放行）。</p>
 *
 * <p>副作用：开关开 + 手上拿盾时，右键的<b>全部</b>动作都被拦截
 * （放方块、开箱子等）——这是「禁用右键举盾」的语义：盾在手上时右键不干活，
 * 该干的活由触控面板 {@code TweakUseExecutor.performUseClick} 代执行
 * （直接调 {@code gameMode.useItemOn / useItem}，不经过这里）。</p>
 */
@Mixin(ShieldItem.class)
public abstract class RightClickShieldGateMixin {
    @Inject(method = "use(Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder;",
            at = @At("HEAD"), cancellable = true)
    private void touchController$cancelRightClickShieldRaise(Level level, Player player, InteractionHand hand, CallbackInfoReturnable<InteractionResultHolder> info) {
        // 旁路：我们的潜行举盾走同一条链路，放行。
        if (SneakShieldRaiseGate.INSTANCE.isBypassing()) {
            return;
        }
        GlobalConfigHolder configHolder = (GlobalConfigHolder) KoinJavaComponent.getOrNull(GlobalConfigHolder.class);
        if (configHolder == null || !configHolder.getConfig().getValue().getTweaks().getSneakShield()) {
            // 功能关：走原版。
            return;
        }
        // 功能开 + 手上拿盾：右键不举盾（整次右键吞掉，右键通道干净）。
        info.setReturnValue(InteractionResultHolder.sidedSuccess(null, level.isClientSide));
        info.cancel();
    }
}
