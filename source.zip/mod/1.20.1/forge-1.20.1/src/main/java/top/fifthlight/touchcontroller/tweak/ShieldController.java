package top.fifthlight.touchcontroller.tweak;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.common.ToolActions;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import top.fifthlight.touchcontroller.common.config.TweakSwitches;

/**
 * 「潜行举盾」客户端核心——照参考版 ClientInputHandler 移植。
 *
 * <p>不模拟右键，而是「直接驱动原版使用流程 + 点击保底代执行」：</p>
 * <ol>
 *   <li><b>举起</b>：潜行且手上有盾时，直接走原版正规管道 {@code gameMode.useItem(player, hand)}——
 *       和真实右键举盾发完全一样的数据包，服务端自动进入格挡状态。</li>
 *   <li><b>防抽搐</b>：把 {@code Minecraft.gameMode} 换成子类 {@link ShieldAwareGameMode}——
 *       潜行举盾期间屏蔽原版「右键没按住就收盾」的强制释放；同时在其 {@code useItemOn} 里
 *       给「任何物品单击方块」补一个兜底挥手。</li>
 *   <li><b>让路 + 点击保底代执行</b>：举盾期间一旦出现左键（攻击/挖掘）或右键（放方块/开箱）输入，
 *       先收盾，然后在同一 tick 内自己消费并执行这次点击：准星是生物就攻击，是方块就
 *       开始挖掘/使用，都没命中就挥空。判定不只看 {@code isDown()}，还会主动
 *       {@code consumeClick()} 消费点击队列，兼容 TouchController 这类通过给原版
 *       {@code KeyMapping} 直接排队点击的触摸模组。</li>
 *   <li><b>站立不举盾</b>：盾只在潜行期间举着；一旦站起来或打开任何界面，立刻收盾。</li>
 *   <li><b>右键不举盾</b>：监听 {@link PlayerInteractEvent.RightClickItem} 取消未潜行时的盾牌右键；
 *       潜行自动举盾用 {@code sneakShield} 标记豁免自己。</li>
 * </ol>
 *
 * <p><b>为什么这比之前的「USE 键静默锁」方案安全</b>：锁方案让 {@code keyUse.isDown()} 恒为 true，
 * 原生 {@code handleKeybinds} 每 tick 看到「右键按着」就调 {@code startUseItem}，在盾刚被
 * {@code releaseUsingItem} 收掉、use-item 状态机没落定的窗口里解引用 null 的 useItem 字段 →
 * NPE（日志 L430 实锤，堆栈直接落在 {@code Minecraft.startUseItem}，根本不经 TouchController）。
 * 本方案键位通道保持干净，原生 {@code startUseItem} 永远不会被我们的锁触发；盾的「保持」靠
 * {@link ShieldAwareGameMode#releaseUsingItem} 屏蔽强制释放，盾的「收 / 举」由本类在 tick 级
 * （早于 {@code handleKeybinds}）主动发起，时序与原生 tick 隔离。</p>
 */
@Mod.EventBusSubscriber(modid = "touchcontroller", value = Dist.CLIENT)
public final class ShieldController {

    /** 是否正处于「潜行举盾」（盾是由本类的潜行逻辑举起的）。 */
    private static boolean sneakShield = false;

    /** 是否正处在 {@link #performUse} 的举盾点击代执行流程中。用于让 {@code useItemOn}
     *  覆写的兜底挥手在此路径上让行，避免与 {@code performUse} 自己的挥手重复。 */
    private static boolean inPerformedUse = false;

    /** 当前 tick 是否已经为「单击方块」补过主手兜底挥手。每 tick 开始时清零。 */
    private static boolean fallbackSwung = false;

    /** 原版 {@code Minecraft#rightClickDelay}，用于让代执行的右键遵守原版 4 tick 连点间隔。 */
    private static final Field RIGHT_CLICK_DELAY_FIELD = findRightClickDelayField();

    private ShieldController() {
    }

    // ------------------------------------------------------------------
    // 每 tick 决策（Phase.START：早于原版 handleKeybinds，点击永远先被我们看到）
    // ------------------------------------------------------------------

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.START) {
            return;
        }
        if (!TweakSwitches.current().getSneakShield()) {
            sneakShield = false;
            fallbackSwung = false;
            return;
        }
        Minecraft minecraft = Minecraft.getInstance();
        LocalPlayer player = minecraft.player;
        if (player == null || minecraft.gameMode == null || minecraft.level == null) {
            sneakShield = false;
            fallbackSwung = false;
            return;
        }
        fallbackSwung = false;
        ensureShieldAwareGameMode(minecraft);

        // 标记与实际状态对齐（破盾复位的根因修复）：
        // 盾被斧头破盾时，服务端 stopUsingItem 把「正在使用物品」位清掉并同步到客户端，
        // 但没有东西通知本类去复位 sneakShield 标记。这里每 tick 对一次账：
        // 只要实际没在举盾，标记就跟着复位，冷却一结束就能正常再次举起。
        if (sneakShield && !isUsingShield(player)) {
            sneakShield = false;
        }

        KeyMapping keyAttack = minecraft.options.keyAttack;
        KeyMapping keyUse = minecraft.options.keyUse;

        // 规则一：站立不举盾——盾只在下蹲时有效，站起来或打开界面立刻收盾。
        if (isUsingShield(player) && (!player.isCrouching() || minecraft.screen != null)) {
            dropShield(minecraft, player);
            return;
        }

        // 规则二：让路 + 点击保底代执行——举盾期间任何左/右键（含 TouchController 触摸点击）
        // 都要先收盾，并在 handleKeybinds 之前自己消费并真正执行，点击才不会被原版丢弃。
        if (isUsingShield(player)) {
            boolean attackHeld = keyAttack.isDown();
            boolean useHeld = keyUse.isDown();
            boolean attackClicked = keyAttack.consumeClick();
            boolean useClicked = keyUse.consumeClick();
            if (attackHeld || useHeld || attackClicked || useClicked) {
                dropShield(minecraft, player);
                if (attackClicked) {
                    performAttack(minecraft, player);
                }
                if (useClicked) {
                    performUse(minecraft, player);
                }
                return;
            }
        }

        // 规则三：举起——蹲下 + 手上有盾 + 两手都没按 + 没在用别的物品（吃东西/拉弓期间不打扰）。
        if (!sneakShield && !player.isUsingItem()
                && !keyAttack.isDown() && !keyUse.isDown()
                && !minecraft.gameMode.isDestroying()) {
            tryRaise(minecraft, player);
        }
    }

    /** 收盾：先清标记再走原版释放（会同步发送释放数据包，服务端状态随之复位）。 */
    private static void dropShield(Minecraft minecraft, LocalPlayer player) {
        sneakShield = false;
        if (isUsingShield(player)) {
            minecraft.gameMode.releaseUsingItem(player);
        }
    }

    // ------------------------------------------------------------------
    // 四周放置（非举盾路径）：把原版准星临时换成「脚下前方那一格的边」
    // ------------------------------------------------------------------

    /**
     * 基岩版「四周放置」在普通路径上的接入点。
     *
     * <p>TouchController 短按<b>空气</b>时同样会发「使用」点击
     * （{@code CrosshairTarget.BLOCK, CrosshairTarget.MISS -> useKeyState.click()}），
     * 所以触摸点方块边缘这一下也会走到这里，不必再去伪造准星。</p>
     *
     * <p>举盾期间点右键时，本类在 {@code handleKeybinds} 之前就把点击消费掉（见规则二），
     * {@code startUseItem} 根本不会执行，那条路走的是 {@link #performUseInternal} 里的同一套判定，
     * 这里不必也不该重复处理。</p>
     */
    @SubscribeEvent
    public static void onUseItemInput(net.minecraftforge.client.event.InputEvent.InteractionKeyMappingTriggered event) {
        if (!event.isUseItem() || !event.getHand().equals(InteractionHand.MAIN_HAND)) {
            return;
        }
        Minecraft minecraft = Minecraft.getInstance();
        LocalPlayer player = minecraft.player;
        if (player == null || minecraft.level == null || minecraft.screen != null) {
            return;
        }
        HitResult hit = minecraft.hitResult;
        if (hit != null && hit.getType() != HitResult.Type.MISS) {
            return;
        }
        BlockHitResult reachAround = ReachAroundPlacement.find(player, player.getItemInHand(event.getHand()));
        if (reachAround != null) {
            minecraft.hitResult = reachAround;
        }
    }

    // ------------------------------------------------------------------
    // 点击保底代执行：语义与原版 startAttack / startUseItem 保持一致，
    // 只是不再受「正在使用物品」丢点击的影响。规则二已消费点击队列并调用下面两个方法。
    // ------------------------------------------------------------------

    /** 对应原版 {@code Minecraft#startAttack}：准星是生物就攻击，是方块就开始挖掘，否则挥空。 */
    private static void performAttack(Minecraft minecraft, LocalPlayer player) {
        HitResult hit = minecraft.hitResult;
        player.resetAttackStrengthTicker();
        if (hit == null) {
            player.swing(InteractionHand.MAIN_HAND);
            return;
        }
        switch (hit.getType()) {
            case ENTITY -> {
                Entity target = ((EntityHitResult) hit).getEntity();
                if (target != null && target.isAttackable() && !target.isSpectator()) {
                    minecraft.gameMode.attack(player, target);
                }
                player.swing(InteractionHand.MAIN_HAND);
            }
            case BLOCK -> {
                BlockHitResult blockHit = (BlockHitResult) hit;
                if (!minecraft.level.isEmptyBlock(blockHit.getBlockPos())) {
                    minecraft.gameMode.startDestroyBlock(blockHit.getBlockPos(), blockHit.getDirection());
                }
                player.swing(InteractionHand.MAIN_HAND);
            }
            default -> player.swing(InteractionHand.MAIN_HAND);
        }
    }

    /**
     * 对应原版 {@code Minecraft#startUseItem}：按主手→副手依次尝试交互/放置/使用。
     * 循环是否继续/结束仍按 {@link InteractionResult#consumesAction()} 判断。
     */
    private static void performUse(Minecraft minecraft, LocalPlayer player) {
        if (minecraft.gameMode.isDestroying()) {
            return;
        }
        inPerformedUse = true;
        try {
            performUseInternal(minecraft, player);
        } finally {
            inPerformedUse = false;
        }
    }

    private static void performUseInternal(Minecraft minecraft, LocalPlayer player) {
        // 与原版一致：每次使用后等待 4 tick 才允许下一次，防止按住右键疯狂连放。
        resetRightClickDelay(minecraft);
        HitResult hit = minecraft.hitResult;
        final boolean blockTapped = hit != null && hit.getType() == HitResult.Type.BLOCK;
        // 准星对着空气（MISS）时，先试基岩版「四周放置」：脚下前方那一格的边缘。
        // 必须排在两只手的常规使用之前：盾在主手时，常规流程里的 useItem 会立刻把盾重新举起来
        // 并 consumesAction 返回，循环根本轮不到副手那摞方块——这正是「举盾时四周放置不生效」的根因。
        if (hit == null || hit.getType() == HitResult.Type.MISS) {
            InteractionHand reachHand = blockItemHand(player);
            if (reachHand != null) {
                BlockHitResult reachAround = ReachAroundPlacement.find(player, player.getItemInHand(reachHand));
                if (reachAround != null) {
                    InteractionResult result = minecraft.gameMode.useItemOn(player, reachHand, reachAround);
                    if (result.consumesAction()) {
                        player.swing(result.shouldSwing() ? reachHand : InteractionHand.MAIN_HAND);
                        return;
                    }
                }
            }
        }
        for (InteractionHand hand : InteractionHand.values()) {
            ItemStack stack = player.getItemInHand(hand);
            if (stack.isEmpty()) {
                continue;
            }
            // 该手是盾就跳过 useItem（盾的举 / 收由本类在 tick 级主动驱动，不在代执行里碰）；
            // 方块 / 生物交互在上面已单独走 useItemOn / interact，跳过盾手不影响它们。
            if (isShield(stack)) {
                continue;
            }
            if (hit != null && hit.getType() == HitResult.Type.ENTITY) {
                EntityHitResult entityHit = (EntityHitResult) hit;
                Entity entity = entityHit.getEntity();
                if (entity == null) {
                    continue;
                }
                if (minecraft.level != null
                        && !minecraft.level.getWorldBorder().isWithinBounds(entity.blockPosition())) {
                    return;
                }
                InteractionResult result = minecraft.gameMode.interactAt(player, entity, entityHit, hand);
                if (!result.consumesAction()) {
                    result = minecraft.gameMode.interact(player, entity, hand);
                }
                if (result.consumesAction()) {
                    if (result.shouldSwing()) {
                        player.swing(hand);
                    }
                    return;
                }
            } else if (blockTapped) {
                BlockHitResult blockHit = (BlockHitResult) hit;
                InteractionResult result = minecraft.gameMode.useItemOn(player, hand, blockHit);
                if (result.consumesAction()) {
                    player.swing(result.shouldSwing() ? hand : InteractionHand.MAIN_HAND);
                    return;
                }
            } else if (hit == null || hit.getType() == HitResult.Type.MISS) {
                // 兜底：理论上不会走到这里（MISS 已经在循环前先用 blockItemHand 处理过）。
                BlockHitResult reachAround = ReachAroundPlacement.find(player, stack);
                if (reachAround != null) {
                    InteractionResult result = minecraft.gameMode.useItemOn(player, hand, reachAround);
                    if (result.consumesAction()) {
                        player.swing(result.shouldSwing() ? hand : InteractionHand.MAIN_HAND);
                        return;
                    }
                }
            }
            InteractionResult itemResult = minecraft.gameMode.useItem(player, hand);
            if (itemResult.consumesAction()) {
                player.swing(itemResult.shouldSwing() ? hand : InteractionHand.MAIN_HAND);
                return;
            }
        }
        // 主副手都没消耗动作（含两只手都空）：只要准星确实点在方块上，就补一次主手挥动。
        if (blockTapped) {
            player.swing(InteractionHand.MAIN_HAND);
        }
    }

    private static void resetRightClickDelay(Minecraft minecraft) {
        if (RIGHT_CLICK_DELAY_FIELD == null) {
            return;
        }
        try {
            RIGHT_CLICK_DELAY_FIELD.setInt(minecraft, 4);
        } catch (ReflectiveOperationException ignored) {
            // 反射失败仅影响连点节奏，不影响功能。
        }
    }

    private static Field findRightClickDelayField() {
        try {
            Field field = Minecraft.class.getDeclaredField("rightClickDelay");
            field.setAccessible(true);
            return field;
        } catch (ReflectiveOperationException ignored) {
            return null;
        }
    }

    // ------------------------------------------------------------------
    // 举盾：潜行时直接走原版 useItem 管道，数据包、服务端同步、格挡计时全归原版管。
    // ------------------------------------------------------------------

    private static void tryRaise(Minecraft minecraft, LocalPlayer player) {
        if (player.isDeadOrDying() || minecraft.screen != null || !player.isCrouching()) {
            return;
        }
        InteractionHand hand = shieldHand(player);
        if (hand == null) {
            return;
        }
        ItemStack stack = player.getItemInHand(hand);
        if (player.getCooldowns().isOnCooldown(stack.getItem())) {
            return;
        }
        // 必须先立标记：useItem 内部会触发 RightClickItem 事件，标记是豁免自己的依据。
        sneakShield = true;
        minecraft.gameMode.useItem(player, hand);
        if (!isUsingShield(player)) {
            // 没举成（物品冷却、被取消等）：复位标记，避免误屏蔽后续的释放。
            sneakShield = false;
        }
    }

    /** 盾在哪只手：<b>副手优先</b>（让主手自由——用户要的主手挖/攻击/放方块），主手没有盾才用主手。 */
    private static InteractionHand shieldHand(LocalPlayer player) {
        if (isShield(player.getOffhandItem())) {
            return InteractionHand.OFF_HAND;
        }
        if (isShield(player.getMainHandItem())) {
            return InteractionHand.MAIN_HAND;
        }
        return null;
    }

    /** 拿着方块的那只手：主手优先、没有再看副手；两只手都不是方块返回 {@code null}。 */
    private static InteractionHand blockItemHand(LocalPlayer player) {
        if (ReachAroundPlacement.isBlockItem(player.getMainHandItem())) {
            return InteractionHand.MAIN_HAND;
        }
        if (ReachAroundPlacement.isBlockItem(player.getOffhandItem())) {
            return InteractionHand.OFF_HAND;
        }
        return null;
    }

    // ------------------------------------------------------------------
    // 换掉 gameMode：只屏蔽「右键没按住就强制收盾」这一个行为
    // ------------------------------------------------------------------

    /**
     * 原版在重生/换维度时会重建 {@code MultiPlayerGameMode}，所以每 tick 检查一次，
     * 不是我们自己的实例就补装一份并拷贝全部运行时状态（游戏模式、破坏进度等）。
     */
    private static void ensureShieldAwareGameMode(Minecraft minecraft) {
        if (minecraft.gameMode instanceof ShieldAwareGameMode) {
            return;
        }
        ClientPacketListener connection = minecraft.getConnection();
        if (connection == null) {
            return;
        }
        ShieldAwareGameMode replacement = new ShieldAwareGameMode(minecraft, connection);
        for (Field field : MultiPlayerGameMode.class.getDeclaredFields()) {
            if (Modifier.isStatic(field.getModifiers()) || Modifier.isFinal(field.getModifiers())) {
                continue;
            }
            field.setAccessible(true);
            try {
                field.set(replacement, field.get(minecraft.gameMode));
            } catch (ReflectiveOperationException ignored) {
                // 单个字段拷贝失败不影响其余状态。
            }
        }
        minecraft.gameMode = replacement;
    }

    private static final class ShieldAwareGameMode extends MultiPlayerGameMode {

        ShieldAwareGameMode(Minecraft minecraft, ClientPacketListener connection) {
            super(minecraft, connection);
        }

        @Override
        public void releaseUsingItem(Player player) {
            if (sneakShield && player instanceof LocalPlayer localPlayer && isUsingShield(localPlayer)) {
                // 潜行举盾期间：屏蔽原版「右键没按住就收盾」的强制释放，杜绝抽搐。
                // 放盾一律由本类主动发起（dropShield），不漏发数据包。
                return;
            }
            super.releaseUsingItem(player);
        }

        /**
         * 通用「单击方块兜底挥手」入口：无论是否举盾都生效。
         * 原版 startUseItem 只在交互结果为 SUCCESS（shouldSwing 为真，如开箱、放方块）才挥手；
         * 其余（PASS/FAIL/CONSUME）一律不挥。这里只要原版不会挥（!ret.shouldSwing()），
         * 就补一次主手挥动，每 tick 最多一次（fallbackSwung），主副手不会各挥一下。
         * 举盾代执行路径（performUse）已有自己的兜底挥手，用 inPerformedUse 标志让其让行。
         */
        @Override
        public InteractionResult useItemOn(LocalPlayer player, InteractionHand hand, BlockHitResult result) {
            InteractionResult ret = super.useItemOn(player, hand, result);
            if (!inPerformedUse && !ret.shouldSwing() && !fallbackSwung) {
                player.swing(InteractionHand.MAIN_HAND);
                fallbackSwung = true;
            }
            return ret;
        }
    }

    // ------------------------------------------------------------------
    // 右键不举盾（豁免自己的自动举盾）
    // ------------------------------------------------------------------

    /**
     * 真实右键落在盾牌上 → 取消：盾只能靠潜行举起。
     * 开箱子/工作台走 RightClickBlock，和村民互动走 EntityInteract，
     * 都不经过这里，不受影响。
     */
    @SubscribeEvent
    public static void onRightClickItem(PlayerInteractEvent.RightClickItem event) {
        if (event.getEntity() == null) {
            return;
        }
        if (isShield(event.getItemStack()) && !sneakShield) {
            event.setCanceled(true);
        }
    }

    // ------------------------------------------------------------------
    // 退出世界/断线时清理状态
    // ------------------------------------------------------------------

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        sneakShield = false;
    }

    // ------------------------------------------------------------------
    // 内部辅助
    // ------------------------------------------------------------------

    private static boolean isUsingShield(LocalPlayer player) {
        return player.isUsingItem() && isShield(player.getUseItem());
    }

    private static boolean isShield(ItemStack stack) {
        return stack != null && !stack.isEmpty() && stack.canPerformAction(ToolActions.SHIELD_BLOCK);
    }
}
