package top.fifthlight.touchcontroller.tweak;

import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.ForgeMod;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import top.fifthlight.touchcontroller.common.config.TweakSwitches;

/**
 * 「六格交互距离」：把玩家的伸手长度统一改成 6 格。
 *
 * <h3>原版的两套距离</h3>
 * <ul>
 *   <li>方块触及距离（{@code forge:block_reach}）：默认 4.5 格，决定能挖多远、能开多远的箱子/门；</li>
 *   <li>实体触及距离（{@code forge:entity_reach}）：默认 3.0 格，决定能打到多远的怪。</li>
 * </ul>
 * 这两项就是 Forge 挂在玩家身上的属性（属性＝给生物挂数值的机制，生命值、移速也是属性），
 * 所以直接改基础值即可，不用自己去改射线检测。
 *
 * <h3>为什么要分两处</h3>
 * 玩家每次进世界、换维度、复活，游戏都会重建玩家实体，属性随之回到默认值：
 * {@link EntityJoinLevelEvent} 正好在这些时刻触发，第一时间补上；
 * {@link TickEvent.PlayerTickEvent} 作为兜底，被别的模组或指令改回原值时也能纠正回来。
 *
 * <h3>关掉开关时</h3>
 * 只把「恰好是我们写的 6 格」改回原版默认值，别的模组改过的数值不碰，
 * 免得关掉本功能时把别人的伸手距离一起抹掉。
 */
@Mod.EventBusSubscriber(modid = "touchcontroller")
public final class ExtraReach {

    /** 目标交互距离：方块、实体都统一 6 格。 */
    private static final double REACH_BLOCKS = 6.0D;

    /** 原版的方块伸手长度（格）。 */
    private static final double DEFAULT_BLOCK_REACH = 4.5D;

    /** 原版的实体伸手长度（格）。 */
    private static final double DEFAULT_ENTITY_REACH = 3.0D;

    private ExtraReach() {
    }

    /** 玩家进入世界（进服、换维度、复活）时立刻设置一次。 */
    @SubscribeEvent
    public static void onEntityJoinLevel(EntityJoinLevelEvent event) {
        if (event.getEntity() instanceof Player player) {
            applyReach(player);
        }
    }

    /** 兜底：数值被改回原值时纠回来（每刻只在结尾检查一次）。 */
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase == TickEvent.Phase.END) {
            applyReach(event.player);
        }
    }

    private static void applyReach(Player player) {
        setReach(player, ForgeMod.BLOCK_REACH.get(), DEFAULT_BLOCK_REACH);
        setReach(player, ForgeMod.ENTITY_REACH.get(), DEFAULT_ENTITY_REACH);
    }

    private static void setReach(Player player, Attribute attribute, double defaultValue) {
        AttributeInstance instance = player.getAttribute(attribute);
        // 属性没挂上（极少数情况，比如被数据包移除了）就跳过，别让异常打断游戏。
        if (instance == null) {
            return;
        }
        boolean enabled = TweakSwitches.current().getExtraReach();
        if (enabled) {
            // 只在数值确实不对时才写，避免每刻都把属性标脏、白白往客户端同步。
            if (instance.getBaseValue() != REACH_BLOCKS) {
                instance.setBaseValue(REACH_BLOCKS);
            }
        } else if (instance.getBaseValue() == REACH_BLOCKS) {
            // 只还原我们自己写过的那一份，不动其他模组的伸手距离。
            instance.setBaseValue(defaultValue);
        }
    }
}
