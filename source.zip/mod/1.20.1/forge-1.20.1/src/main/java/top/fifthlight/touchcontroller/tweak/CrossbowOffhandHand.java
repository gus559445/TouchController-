package top.fifthlight.touchcontroller.tweak;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import top.fifthlight.touchcontroller.common.config.TweakSwitches;

/**
 * 「副手拿着东西时，主手弩的第一人称绘制」。
 *
 * <h3>为什么必须自己画</h3>
 * <p>原版 {@code ItemInHandRenderer#renderArmWithItem} 里弩那一支是提前 return 的，
 * 模组拿不到「按副手有没有东西开关」的接口。更关键的是原版 {@code evaluateWhichHandsToRender}：
 * <b>主手弩一旦上膛，就只画主手、副手整只手跳过</b>，连 Forge 的副手 {@link RenderHandEvent}
 * 都不会发出——所以想让副手不消失，只能在主手这次事件里替原版补画。</p>
 *
 * <h3>本功能的行为</h3>
 * <p>命中条件：主手拿弩 + 副手有物品 + 弩已经上膛、且人没在拉。这时：</p>
 * <ol>
 *   <li><b>弩的位置改成和「未装填」完全一致</b>。原版给上膛的弩额外加了
 *       「往左推 0.641864、再偏 10°」的小动作（就是上膛标记），这里去掉它，
 *       直接用「没上膛」那条变换重画，看起来和空弩一模一样。</li>
 *   <li><b>副手不再消失</b>。原版这时整只手跳过，就按原版副手那套变换把它补画回来；
 *       如果原版本来就会画副手（例如玩家正在用副手吃东西），就交给原版，绝不重复画两遍。</li>
 * </ol>
 * <p><b>上弦过程中</b>（按住右键上弦）完全交给原版：原版这时端着弩、并且把副手收起来。
 * <b>没装填、也没在拉</b>时同样交给原版，原版本来就把两只手都画出来。</p>
 *
 * <p>所有变换都写在自己 {@code pushPose/popPose} 的这一层里，不会漏到随后画的别的渲染上。</p>
 */
@Mod.EventBusSubscriber(modid = "touchcontroller", value = Dist.CLIENT)
public final class CrossbowOffhandHand {

    private CrossbowOffhandHand() {
    }

    @SubscribeEvent
    public static void onRenderHand(RenderHandEvent event) {
        if (event.getHand() != InteractionHand.MAIN_HAND) {
            return;
        }
        if (!TweakSwitches.current().getCrossbowOffhandRender()) {
            return;
        }
        Minecraft minecraft = Minecraft.getInstance();
        LocalPlayer player = minecraft.player;
        if (player == null || player.isScoping()) {
            return;
        }
        ItemStack stack = event.getItemStack();
        if (stack.isEmpty() || !(stack.getItem() instanceof CrossbowItem)) {
            return;
        }
        // 只在「副手拿着东西」时接管；副手空手保持原版第一人称手感。
        if (player.getOffhandItem().isEmpty()) {
            return;
        }
        // 正在给主手弩上弦（原版端着弩、并且把副手收起来）：交给原版。
        if (player.isUsingItem() && player.getUsedItemHand() == InteractionHand.MAIN_HAND
                && player.getUseItemRemainingTicks() > 0) {
            return;
        }
        // 没上膛的弩原版就是「未装填」的样子，也交给原版。
        if (!CrossbowItem.isCharged(stack)) {
            return;
        }

        // 到这里：副手有物品 + 主手弩已上膛。取消原版这只手，自己按「未装填」那条变换重画。
        event.setCanceled(true);

        ItemInHandRenderer renderer = minecraft.getEntityRenderDispatcher().getItemInHandRenderer();
        PoseStack poseStack = event.getPoseStack();
        HumanoidArm arm = player.getMainArm();

        poseStack.pushPose();
        try {
            applyIdleCrossbowPose(poseStack, arm, event.getSwingProgress(), event.getEquipProgress());
            renderHandItem(renderer, player, stack, arm, poseStack, event);
        } finally {
            poseStack.popPose();
        }

        // 副手这一帧原版会不会自己画？会画就交给它；原版因为「主手弩已上膛」整只手跳过时，
        // 由我们补画，副手的物品才不会凭空消失。
        if (!vanillaRendersOffhand(player)) {
            poseStack.pushPose();
            try {
                renderOffhand(renderer, player, poseStack, event);
            } finally {
                poseStack.popPose();
            }
        }
    }

    // ------------------------------------------------------------------
    // 主手弩：复刻原版「未装填」那条变换
    // ------------------------------------------------------------------

    /**
     * 原版 {@code renderArmWithItem} 里弩分支、<b>非使用</b>那条路径的完整变换，数值照抄 1.20.1：
     * 挥动偏移（{@code f/f1/f2}）→ {@code applyItemArmTransform}（{@code ±0.56, -0.52-e*0.6, -0.72}）→
     * {@code applyItemArmAttackTransform}（四段旋转）。
     *
     * <p>原版在这条路径末尾还有一段「已上膛就额外往左推 0.641864、再偏 10°」的补偿，
     * 这里<b>故意不写</b>：这样上膛的弩和未装填的弩位置完全一致。</p>
     */
    private static void applyIdleCrossbowPose(PoseStack poseStack, HumanoidArm arm,
            float swingProgress, float equipProgress) {
        int i = arm == HumanoidArm.RIGHT ? 1 : -1;

        float f = -0.4F * Mth.sin(Mth.sqrt(swingProgress) * (float) Math.PI);
        float f1 = 0.2F * Mth.sin(Mth.sqrt(swingProgress) * ((float) Math.PI * 2.0F));
        float f2 = -0.2F * Mth.sin(swingProgress * (float) Math.PI);
        poseStack.translate((float) i * f, f1, f2);

        poseStack.translate((float) i * 0.56F, -0.52F + equipProgress * -0.6F, -0.72F);

        applyItemArmAttackTransform(poseStack, arm, swingProgress);
    }

    /** 原版 {@code applyItemArmAttackTransform}（挥动带来的四段旋转），数值照抄。 */
    private static void applyItemArmAttackTransform(PoseStack poseStack, HumanoidArm arm, float swingProgress) {
        int i = arm == HumanoidArm.RIGHT ? 1 : -1;

        float g = Mth.sin(swingProgress * swingProgress * (float) Math.PI);
        poseStack.mulPose(Axis.YP.rotationDegrees((float) i * (45.0F + -20.0F * g)));
        float h = Mth.sin(Mth.sqrt(swingProgress) * (float) Math.PI);
        poseStack.mulPose(Axis.ZP.rotationDegrees((float) i * h * -20.0F));
        poseStack.mulPose(Axis.XP.rotationDegrees(h * -80.0F));
        poseStack.mulPose(Axis.YP.rotationDegrees((float) i * -45.0F));
    }

    // ------------------------------------------------------------------
    // 副手：原版会跳过时补画
    // ------------------------------------------------------------------

    /**
     * 复刻原版 {@code evaluateWhichHandsToRender}：
     * 返回「原版这一帧会不会自己把副手画出来」。返回 {@code false} 时说明副手被整只手跳过了，需要补。
     */
    private static boolean vanillaRendersOffhand(LocalPlayer player) {
        if (player.isUsingItem()) {
            ItemStack useItem = player.getUseItem();
            if (!useItem.is(Items.BOW) && !useItem.is(Items.CROSSBOW)) {
                // 正在用的不是弓弩（举盾、吃东西…）：只有「主手在用 + 副手是上膛好的弩」才会跳过副手。
                return !(player.getUsedItemHand() == InteractionHand.MAIN_HAND
                        && isChargedCrossbow(player.getOffhandItem()));
            }
            // 正在用的就是弓弩：原版只画正在用的那只手。
            return player.getUsedItemHand() == InteractionHand.OFF_HAND;
        }
        // 没在用物品：主手弩已上膛时原版只画主手，其余两只手都画。
        return !isChargedCrossbow(player.getMainHandItem());
    }

    /**
     * 补画副手。副手这时一定没有被使用，所以走原版「通用物品」的非使用路径：
     * 挥动偏移 → {@code applyItemArmTransform} → {@code applyItemArmAttackTransform}；
     * 副手拿的若是弩则走弩的空闲变换（原版的上膛补偿只作用于主手，副手本来就没有）。
     *
     * <p>副手静止时原版的高度就是满的（{@code equipProgress = 0}），这里按 0 处理，
     * 不重做「刚切到副手那几帧的抬起动画」——那段动画只在换物品的瞬间有，肉眼几乎看不到。</p>
     */
    private static void renderOffhand(ItemInHandRenderer renderer, LocalPlayer player, PoseStack poseStack,
            RenderHandEvent event) {
        ItemStack off = player.getOffhandItem();
        if (off.isEmpty()) {
            return;
        }
        // 地图走的是原版另一套双手地图变换，这里不擅自重画：保持「原版本来就不画」的状态。
        if (off.is(Items.FILLED_MAP)) {
            return;
        }

        HumanoidArm arm = player.getMainArm().getOpposite();
        float swingProgress = player.swingingArm == InteractionHand.OFF_HAND
                ? player.getAttackAnim(event.getPartialTick())
                : 0.0F;

        if (off.getItem() instanceof CrossbowItem) {
            applyIdleCrossbowPose(poseStack, arm, swingProgress, 0.0F);
        } else {
            int i = arm == HumanoidArm.RIGHT ? 1 : -1;
            float f = -0.4F * Mth.sin(Mth.sqrt(swingProgress) * (float) Math.PI);
            float f1 = 0.2F * Mth.sin(Mth.sqrt(swingProgress) * ((float) Math.PI * 2.0F));
            float f2 = -0.2F * Mth.sin(swingProgress * (float) Math.PI);
            poseStack.translate((float) i * f, f1, f2);
            poseStack.translate((float) i * 0.56F, -0.52F, -0.72F);
            applyItemArmAttackTransform(poseStack, arm, swingProgress);
        }
        renderHandItem(renderer, player, off, arm, poseStack, event);
    }

    /** 按手臂决定用哪只手的物品模型、以及原版那个 leftHand 标记。 */
    private static void renderHandItem(ItemInHandRenderer renderer, LocalPlayer player, ItemStack stack,
            HumanoidArm arm, PoseStack poseStack, RenderHandEvent event) {
        boolean rightArm = arm == HumanoidArm.RIGHT;
        renderer.renderItem(player, stack,
                rightArm ? ItemDisplayContext.FIRST_PERSON_RIGHT_HAND : ItemDisplayContext.FIRST_PERSON_LEFT_HAND,
                !rightArm,
                poseStack,
                event.getMultiBufferSource(),
                event.getPackedLight());
    }

    /** 原版 {@code isChargedCrossbow}：是弩、并且已经上膛。 */
    private static boolean isChargedCrossbow(ItemStack stack) {
        return stack.is(Items.CROSSBOW) && CrossbowItem.isCharged(stack);
    }
}
